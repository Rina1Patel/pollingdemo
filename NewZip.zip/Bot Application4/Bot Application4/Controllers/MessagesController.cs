﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;
using Microsoft.Bot.Builder.Dialogs;

namespace Bot_Application4
{
    [BotAuthentication]
    public class MessagesController : ApiController
    {
        /// <summary>
        /// POST: api/Messages
        /// Receive a message from a user and reply to it
        /// </summary>
        public async Task<HttpResponseMessage> Post([FromBody]Activity activity)
        {
            if (activity.Type == ActivityTypes.Message)
            {
                //ConnectorClient connector = new ConnectorClient(new Uri(activity.ServiceUrl));
                // calculate something for us to return
                await Conversation.SendAsync(activity,()=> new mathdialog());
            }
            else
            {
                HandleSystemMessage(activity);
            }
            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }

        private Activity HandleSystemMessage(Activity message)
        {
            if (message.Type == ActivityTypes.DeleteUserData)
            {
                // Implement user deletion here
                // If we handle user deletion, return a real message
            }
            else if (message.Type == ActivityTypes.ConversationUpdate)
            {
                // Handle conversation state changes, like members being added and removed
                // Use Activity.MembersAdded and Activity.MembersRemoved and Activity.Action for info
                // Not available in all channels
            }
            else if (message.Type == ActivityTypes.ContactRelationUpdate)
            {
                // Handle add/remove from contact lists
                // Activity.From + Activity.Action represent what happened
            }
            else if (message.Type == ActivityTypes.Typing)
            {
                // Handle knowing tha the user is typing
            }
            else if (message.Type == ActivityTypes.Ping)
            {
            }

            return null;
        }
    }
    [Serializable]
    public class mathdialog : IDialog<object>
    {
        protected int number1;
        protected int number2;
        public async Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceiverStart);
        }
        public async Task MessageReceiverStart(IDialogContext context, IAwaitable<IMessageActivity> argument)
        {
            await context.PostAsync("do want to add or square?");
            context.Wait(MessageReceivedOperationChoice);
        }
        public async Task MessageReceivedOperationChoice(IDialogContext context, IAwaitable<IMessageActivity> argument)
        {
            var message = await argument;
            if(message.Text.Equals("add",StringComparison.InvariantCultureIgnoreCase))
            {
                await context.PostAsync("please provide one number");
                context.Wait(MessageReseivedaddnumber1);
            }
            else if(message.Text.Equals("sroot", StringComparison.InvariantCultureIgnoreCase))
            {
                await context.PostAsync("please enter number for sroot");
                context.Wait(Messagereceivedsrootnum);
            }
            else
            {
                context.Wait(MessageReceiverStart);
            }
        }
        public async Task Messagereceivedsrootnum(IDialogContext context, IAwaitable<IMessageActivity> argument)
        {
            var number = await argument;
           // this.number1 = int.Parse(number.Text);
            this.number1 = int.Parse(number.Text);
            context.PostAsync($"{this.number1} sroot {this.number1 * number1}");
            context.Wait(MessageReceiverStart);


        }
        public async Task MessageReseivedaddnumber1(IDialogContext context, IAwaitable<IMessageActivity> argument)
        {
            var number = await argument;
//            var number = await argument;
            // this.number1 = int.Parse(number.Text);
            this.number1 = int.Parse(number.Text);
            await context.PostAsync("please provide second number");

            // context.PostAsync($"{this.number1} sroot {this.number1 * number1}");
            context.Wait(MessageReseivedaddnumber2);

        }
        public async Task MessageReseivedaddnumber2(IDialogContext context, IAwaitable<IMessageActivity> argument)
        {
            var number = await argument;
            //            var number = await argument;
            // this.number1 = int.Parse(number.Text);
            this.number2 = int.Parse(number.Text);
             context.PostAsync($"{this.number1}+{this.number2} = {this.number1 + number2}");
            context.Wait(MessageReceiverStart);

        }



    }
}